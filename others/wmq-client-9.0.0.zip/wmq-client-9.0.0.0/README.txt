Date : 25/08/2015
Email : support@wso2.com 

Instructions to Install IBM MQ 9.0.0.0 client jars to WSO2 EI 6.1.1.
===============================================================

Prerequisites
-------------

1) Install Java and Set JAVA_HOME environment variable (Prerequisites for Maven) 
2) Install Apache Maven 3.X and Set MAVEN_HOME and M2 environment variables
3) IBM MQ 9.0.0.0 Java libraries (jars)

Build Instructions
------------------

1) Copy following jars from <IBM MQ 9.0.0.0 installation Directory>\java\lib directory to wmq-client\lib .
	*	com.ibm.mq.allclient.jar
	*	fscontext.jar
	*	jms.jar
	*	providerutil.jar

2) Build wmq-client project using Apache Maven with following command line command

	mvn clean install

	
Installing IBM MQ Client jars to WSO2 EI 6.1.1
-----------------------------------------------

1) Stop WSO2 ESB EI 6.1.1 server, if it is already running. 
2) (If present) Remove Old IBM MQ client jars from <EI 6.1.1_Home>\dropins and <EI 6.1.1_Home>\lib
3) Copy wmq-client\target\wmq-client-9.0.0.0.jar to <EI 6.1.1_Home>\dropins
5) Remove following line from <EI 6.1.1_Home>\conf\etc\launch.ini

	javax.jms,\

6) [Important] Regenerate .bindings file with following property.

		Provider Version : 8
		
7) Replace old .bindings file with new .bindings file.  	
8) Start ESB server. 


--- End of Document. ----
